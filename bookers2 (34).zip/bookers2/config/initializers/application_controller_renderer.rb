# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '1afe6c1a0573df8758f4f9cc87a1ef6d12a496548138ec602cbc3a686cb18fa02dfea97ba1378651124117e3ec913c1336f9e340fa596603ab93850160ef8ed0'